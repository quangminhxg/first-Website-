	<div class="header">
        	<img src="imgs/banner2.jpg" />
        </div>